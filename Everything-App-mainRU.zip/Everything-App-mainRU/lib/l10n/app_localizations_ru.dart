// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Russian (`ru`).
class AppLocalizationsRu extends AppLocalizations {
  AppLocalizationsRu([String locale = 'ru']) : super(locale);

  @override
  String get appTitle => 'Everything App';

  @override
  String get navNotes => 'Заметки';

  @override
  String get navFinances => 'Финансы';

  @override
  String get navTracker => 'Трекер';

  @override
  String get navSplitBills => 'Общие счета';

  @override
  String get greetingMorning => 'Доброе утро, солнышко!';

  @override
  String get greetingAfternoon => 'Уже обедали?';

  @override
  String get greetingEvening => 'Добрый вечер!';

  @override
  String get greetingNight => 'Пора спать!';

  @override
  String noteCount(int count) {
    String _temp0 = intl.Intl.pluralLogic(
      count,
      locale: localeName,
      other: '$count заметки',
      one: '$count заметка',
      few: '$count заметки',
      many: '$count заметок',
    );
    return '$_temp0';
  }

  @override
  String get searchNotes => 'Поиск заметок...';

  @override
  String get searchFinances => 'Поиск операций...';

  @override
  String get settingsTitle => 'Настройки';

  @override
  String get newNote => 'Новая заметка';

  @override
  String get newTransaction => 'Новая операция';

  @override
  String get search => 'Поиск';

  @override
  String get save => 'Сохранить';

  @override
  String get cancel => 'Отмена';

  @override
  String get delete => 'Удалить';

  @override
  String get edit => 'Изменить';

  @override
  String get done => 'Готово';

  @override
  String get close => 'Закрыть';

  @override
  String get filter => 'Фильтр';

  @override
  String get sort => 'Сортировка';

  @override
  String get confirm => 'Подтвердить';

  @override
  String get back => 'Назад';

  @override
  String get copy => 'Копировать';

  @override
  String get share => 'Поделиться';

  @override
  String get clear => 'Очистить';

  @override
  String get apply => 'Применить';

  @override
  String get discard => 'Сбросить';

  @override
  String get undo => 'Отменить';

  @override
  String get all => 'Все';

  @override
  String get copiedToClipboard => 'Скопировано в буфер обмена';

  @override
  String get pinnedNotes => 'Закреплённые заметки';

  @override
  String get otherNotes => 'Другие заметки';

  @override
  String get emptyNotesTitle => 'Заметок пока нет';

  @override
  String get emptyNotesSubtitle => 'Нажмите +, чтобы записать свои мысли';

  @override
  String get archive => 'Архив';

  @override
  String get trash => 'Корзина';

  @override
  String get restore => 'Восстановить';

  @override
  String get deletePermanently => 'Удалить навсегда';

  @override
  String get lockedNote => 'Заметка заблокирована';

  @override
  String get appLocked => 'Приложение заблокировано';

  @override
  String get unlock => 'Разблокировать';

  @override
  String get noteTitlePlaceholder => 'Заголовок';

  @override
  String get noteBodyPlaceholder => 'Начните вводить...';

  @override
  String get manageTags => 'Управление тегами';

  @override
  String get income => 'Доход';

  @override
  String get expense => 'Расход';

  @override
  String get balance => 'Баланс';

  @override
  String get netBalance => 'Чистый баланс';

  @override
  String get monthlySpending => 'Расходы за месяц';

  @override
  String get dailySafeToSpend => 'Можно потратить сегодня';

  @override
  String get breakdown => 'Разбивка';

  @override
  String get budgets => 'Бюджеты';

  @override
  String get savings => 'Накопления';

  @override
  String get savingsGoals => 'Цели накоплений';

  @override
  String get deposit => 'Пополнение';

  @override
  String get dailyAccount => 'Текущий счёт';

  @override
  String get savingsVault => 'Копилка';

  @override
  String get targetAmount => 'Целевая сумма';

  @override
  String get currentAmount => 'Текущая сумма';
@override
  String get noTransactionsYet => 'Финансовых данных пока нет';

  @override
  String get categories => 'Категории';

  @override
  String get splitBillsTitle => 'Разделение счетов';

  @override
  String get settleUp => 'Рассчитаться';

  @override
  String get equalSplit => 'Поровну';

  @override
  String get customSplit => 'Индивидуально';

  @override
  String get paidBy => 'Оплатил(а)';

  @override
  String get sendReminder => 'Отправить напоминание';

  @override
  String cycleDay(int day) {
    return 'День цикла $day';
  }

  @override
  String get periodLog => 'Журнал цикла';

  @override
  String get symptoms => 'Симптомы';

  @override
  String get periodStart => 'Начало месячных';

  @override
  String get periodEnd => 'Конец месячных';

  @override
  String get regular => 'Регулярный';

  @override
  String get irregular => 'Нерегулярный';

  @override
  String get appearance => 'Внешний вид и интерфейс';

  @override
  String get theme => 'Тема';

  @override
  String get themeLight => 'Светлая';

  @override
  String get themeDark => 'Тёмная';

  @override
  String get themeSystem => 'Системная';

  @override
  String get language => 'Язык';

  @override
  String get languageSystem => 'Системный';

  @override
  String get currency => 'Валюта';

  @override
  String get security => 'Безопасность и приватность';

  @override
  String get backupRestore => 'Резервное копирование и восстановление';

  @override
  String get about => 'О приложении';

  @override
  String get onDeviceAi => 'Локальный ИИ';
}